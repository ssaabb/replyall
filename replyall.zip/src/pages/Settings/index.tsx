import './Settings.css';

function Settings() {
    return (
        <div className="settings-page">
            <div className="container">
                <h1>설정</h1>
                <p>설정 페이지입니다. 곧 구현될 예정입니다.</p>
            </div>
        </div>
    );
}

export default Settings;
