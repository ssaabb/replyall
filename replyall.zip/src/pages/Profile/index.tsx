import './Profile.css';

function Profile() {
    return (
        <div className="profile-page">
            <div className="container">
                <h1>프로필</h1>
                <p>프로필 페이지입니다. 곧 구현될 예정입니다.</p>
            </div>
        </div>
    );
}

export default Profile;
