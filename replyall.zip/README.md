# 모두의 리뷰 (Everyone's Review)

<div align="center">

![모두의 리뷰](https://img.shields.io/badge/모두의_리뷰-v0.1.0-blue)
![React](https://img.shields.io/badge/React-18.2.0-61DAFB?logo=react)
![TypeScript](https://img.shields.io/badge/TypeScript-5.3.3-3178C6?logo=typescript)
![Vite](https://img.shields.io/badge/Vite-5.0.8-646CFF?logo=vite)

**모든 웹 콘텐츠에 댓글을 달 수 있는 범용 댓글 플랫폼**

[시작하기](#시작하기) • [기능](#주요-기능) • [문서](#문서) • [기여하기](#기여하기)

</div>

---

## 📖 프로젝트 소개

모두의 리뷰는 YouTube, Netflix, Disney+, 웹툰, 웹소설 등 모든 인터넷 콘텐츠에 대해 실시간으로 댓글을 공유할 수 있는 범용 댓글 플랫폼입니다. 사용자들은 콘텐츠의 특정 위치(영상의 타임스탬프, 웹페이지의 스크롤 위치)에 댓글을 달아 정확한 맥락을 공유하고, 다른 사용자들과 소통할 수 있습니다.

## ✨ 주요 기능

- 🎯 **위치 기반 댓글**: 영상의 타임스탬프 또는 웹페이지의 스크롤 위치에 댓글 태깅
- 🛡️ **스마트 필터링**: 스포일러, 광고, 불건전 댓글 자동 차단
- 💬 **실시간 소통**: WebSocket 기반 실시간 댓글 업데이트
- 🌐 **범용 플랫폼**: 모든 웹사이트와 스트리밍 서비스 지원
- 👥 **대댓글 시스템**: 계층형 댓글 구조로 깊이 있는 토론 가능
- 🔔 **알림 시스템**: 댓글, 좋아요, 멘션 알림
- 🌙 **다크 모드**: 눈의 피로를 줄이는 다크 모드 지원

## 🚀 시작하기

### 필수 요구사항

- Node.js 20.x 이상
- npm 또는 yarn

### 설치 방법

1. 저장소 클론
```bash
git clone https://github.com/yourusername/replyall.git
cd replyall
```

2. 의존성 설치
```bash
npm install
```

3. 개발 서버 실행
```bash
npm run dev
```

4. 브라우저에서 `http://localhost:3000` 접속

### 빌드

프로덕션 빌드를 생성하려면:

```bash
npm run build
```

빌드된 파일은 `dist` 폴더에 생성됩니다.

## 📁 프로젝트 구조

```
replyall/
├── src/
│   ├── assets/          # 정적 파일 (이미지, 폰트 등)
│   ├── components/      # 재사용 가능한 컴포넌트
│   │   ├── common/      # 공통 컴포넌트
│   │   ├── comment/     # 댓글 관련 컴포넌트
│   │   └── layout/      # 레이아웃 컴포넌트
│   ├── features/        # Redux 슬라이스
│   │   ├── auth/        # 인증 관련
│   │   ├── comments/    # 댓글 관련
│   │   ├── user/        # 사용자 관련
│   │   └── notifications/ # 알림 관련
│   ├── hooks/           # 커스텀 훅
│   ├── pages/           # 페이지 컴포넌트
│   ├── services/        # API 서비스
│   ├── store/           # Redux 스토어
│   ├── types/           # TypeScript 타입 정의
│   ├── utils/           # 유틸리티 함수
│   ├── App.tsx          # 메인 앱 컴포넌트
│   ├── main.tsx         # 진입점
│   └── index.css        # 글로벌 스타일
├── public/              # 정적 파일
├── PRD.md               # 제품 요구사항 문서
├── TRD.md               # 기술 요구사항 문서
├── package.json
├── tsconfig.json
├── vite.config.ts
└── README.md
```

## 🛠️ 기술 스택

### Frontend
- **프레임워크**: React 18.2
- **빌드 도구**: Vite 5.0
- **언어**: TypeScript 5.3
- **상태 관리**: Redux Toolkit
- **라우팅**: React Router v6
- **스타일링**: CSS Variables + Custom CSS
- **폼 관리**: React Hook Form + Zod
- **애니메이션**: Framer Motion

### Backend (예정)
- **런타임**: Node.js 20+
- **프레임워크**: Express.js / Fastify
- **데이터베이스**: PostgreSQL + Redis
- **인증**: JWT
- **실시간 통신**: WebSocket

## 📚 문서

- [PRD (Product Requirements Document)](./PRD.md) - 제품 요구사항 상세 문서
- [TRD (Technical Requirements Document)](./TRD.md) - 기술 요구사항 및 아키텍처 문서

## 🎨 디자인 시스템

프로젝트는 CSS Variables를 사용한 일관된 디자인 시스템을 제공합니다:

- **컬러 팔레트**: Primary, Secondary, Accent 색상
- **타이포그래피**: Inter 폰트 패밀리
- **스페이싱**: 일관된 간격 시스템
- **다크 모드**: 자동 다크 모드 지원

## 🧪 테스트

```bash
# 유닛 테스트 실행
npm run test

# 테스트 커버리지
npm run test:coverage

# E2E 테스트
npm run test:e2e
```

## 📝 스크립트

- `npm run dev` - 개발 서버 실행
- `npm run build` - 프로덕션 빌드
- `npm run preview` - 빌드 미리보기
- `npm run lint` - ESLint 실행
- `npm run format` - Prettier 포맷팅

## 🤝 기여하기

기여를 환영합니다! 다음 단계를 따라주세요:

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3. Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the Branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 라이선스

이 프로젝트는 MIT 라이선스 하에 배포됩니다.

## 👥 팀

- **개발자**: Your Name
- **디자이너**: Designer Name

## 📞 연락처

프로젝트 링크: [https://github.com/yourusername/replyall](https://github.com/yourusername/replyall)

---

<div align="center">

Made with ❤️ by the 모두의 리뷰 Team

</div>
